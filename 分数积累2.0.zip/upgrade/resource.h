//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by upgrade.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_UPGRADE_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     164
#define IDB_BITMAP2                     165
#define IDB_BITMAP3                     166
#define IDB_BITMAP4                     167
#define IDB_BITMAP5                     168
#define IDB_BITMAP6                     169
#define IDB_BITMAP7                     170
#define IDB_BITMAP8                     171
#define IDB_BITMAP9                     172
#define IDB_BITMAP10                    173
#define IDB_BITMAP11                    174
#define IDB_BITMAP12                    175
#define IDB_BITMAP13                    176
#define IDB_BITMAP14                    177
#define IDB_BITMAP15                    178
#define IDB_BITMAP16                    179
#define IDB_BITMAP17                    180
#define IDB_BITMAP18                    181
#define IDC_READ                        1000
#define IDC_CLEAR                       1001
#define IDC_STATIC_TITLE                1002
#define IDC_STATIC_DETAIL               1003
#define IDC_STATIC_GRADES               1004
#define IDC_STATIC_PICTURE              1005
#define IDC_CLEAR2                      1006
#define IDC_PROGRESS1                   1007
#define IDC_STATIC_TOTALSCORE           1008
#define IDC_STATIC_SHSCORE              1009
#define IDC_STATIC_TODAYSCORE           1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
