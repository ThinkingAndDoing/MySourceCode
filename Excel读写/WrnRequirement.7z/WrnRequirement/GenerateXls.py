#!/usr/bin/python3

import json
import os
import xlwt

def initGlobalVar():
	global _sourceDir
	global _OutputFile
	
	_sourceDir = '.\\Warnings'
	_OutputFile = 'warnings.xls'
	
def readJson(fn):
	with open(fn, 'r') as f:
		data = json.load(f)
		return eval(str(data))

def getWarnings(sourceDir):
	warnings = []
	for wrnFile in os.listdir(sourceDir):
		data = readJson(sourceDir + "\\" + wrnFile)
		warnings.append([data, wrnFile])
	return warnings

def generateNewWarnings(distSheet):

	warnings = getWarnings(_sourceDir)
	distSheet.write(0, 0, 'Name')
	distSheet.write(0, 1, 'DisplayModeOn')
	distSheet.write(0, 2, 'DisplayModeOff')
	distSheet.write(0, 3, 'Lightcolor')
	distSheet.write(0, 4, 'English')
	distSheet.write(0, 5, 'Chinese')
	distSheet.write(0, 6, 'Information')
	row	= 1
	col = 0
	for wrn in warnings:
		distSheet.write(row, col, wrn[0]['Name'])
		distSheet.write(row, col+1, wrn[0]['DisplayModeOn'])
		distSheet.write(row, col+2, wrn[0]['DisplayModeOff'])
		distSheet.write(row, col+3, wrn[0]['Lightcolor'])
		distSheet.write(row, col+4, wrn[0]['English'])
		distSheet.write(row, col+5, wrn[0]['Chinese'].replace(" ", "").replace("\n", ""))
		distSheet.write(row, col+6, wrn[0]['Information'])
		row += 1


if __name__ == "__main__":
	initGlobalVar()
	try:
		distwb = xlwt.Workbook()
		distws = distwb.add_sheet('Warnings',cell_overwrite_ok=True)
	except Exception as e:
		print("Exception:",e)
	else:
		generateNewWarnings(distws)
		distwb.save(_OutputFile)





















