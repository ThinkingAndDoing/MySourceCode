import os
import xlrd
import json
import shutil

#os.chdir('C:\\Users\\uidp8103\\Desktop\\TextCompare\\python\\done\\TestCase')

def initGlobalVar():
	global _SourceFile
	global _SheetName
	global _InputSheetName
	global _distDir

	_SourceFile	='.\\SAIC_IP31_WarningConfiguration.xlsx'
	_SheetName	='WarningConfig'
	_InputSheetName	='UEInput'
	_distDir = '.\\CurWarnings'

def getTableIndex(table):
	global indexName
	global indexChinese
	global indexDisplayMode
	global indexWarningStrategy
	global indexStrategyState
	
	keyName = table.row_values(0)
	indexName = keyName.index("Name")
	indexChinese = keyName.index("Information")
	indexDisplayMode = keyName.index("DisplayMode")
	indexWarningStrategy = keyName.index("WarningStrategy")
	indexStrategyState = keyName.index("StrategyState")

def writeJson(fn, js):
	with open(fn, 'w') as f:
		json.dump(js, f, indent=4, sort_keys=True, ensure_ascii=False)

def generateWarnings(sourceSheet, textSheet):
	getTableIndex(sourceSheet)
	
	print(sourceSheet.nrows)
	for i in range(2, sourceSheet.nrows):
		Chinese = sourceSheet.cell(i,indexChinese).value
		
		Name = Chinese.replace("\n", "")
		
		ChineseLine1 = ""
		ChineseLine2 = ""
		EnglishLine1 = ""
		EnglishLine2 = ""
		col = 1
		row = 0
		KeysName = textSheet.col_values(col)
		try:
			row = KeysName.index(Chinese)
		except:
			print( Chinese + " is not found!")
		else:
			ChineseLine1 = textSheet.cell(row, col+1).value
			ChineseLine2 = textSheet.cell(row, col+2).value
			EnglishLine1 = textSheet.cell(row, col+3).value
			EnglishLine2 = textSheet.cell(row, col+4).value
			
		
		DisplayMode = sourceSheet.cell(i,indexDisplayMode).value
		
		WarningStrategy = sourceSheet.cell(i,indexWarningStrategy).value
		InforCenter = ''
		if WarningStrategy.find('WSList')!=-1:
			InforCenter='Yes'
			
		StrategyState = sourceSheet.cell(i,indexStrategyState).value
		Lightcolor = ''
		if StrategyState.find('Red')!=-1:
			Lightcolor='Red'
		if StrategyState.find('Yellow')!=-1:
			Lightcolor='Yellow'

		ChineseLine1 = ChineseLine1.replace(" ", "")
		ChineseLine2 = ChineseLine2.replace(" ", "")
		EnglishLine1 = EnglishLine1.replace(" ", "")
		EnglishLine2 = EnglishLine2.replace(" ", "")
		_wrn = {"Name":	Name, 
				"ChineseLine1":	ChineseLine1, 
				"ChineseLine2":	ChineseLine2, 
				"EnglishLine1":	EnglishLine1, 
				"EnglishLine2":	EnglishLine2, 
				"DisplayMode":	DisplayMode, 
				"InforCenter":	InforCenter, 
				"Lightcolor":	Lightcolor
				}
		
		wrnFileName = Chinese.replace("\n", "").replace(" ", "").replace("/", "")
		i = 2
		if os.path.exists(_distDir + "\\"+ wrnFileName +".json")==True:
			wrnFileName = wrnFileName + str(i)
			while os.path.exists(_distDir + "\\"+ wrnFileName +".json")==True:
				i+= 1
				wrnFileName = wrnFileName[:-1] + str(i)
				
		writeJson(_distDir + "\\"+ wrnFileName +".json", _wrn)
		#print(Chinese)


if __name__ == "__main__":

	initGlobalVar()
	
	if os.path.exists(_distDir):
		shutil.rmtree(_distDir)
	
	os.mkdir(_distDir)
	
	try:
		sourcewb = xlrd.open_workbook(_SourceFile)
		sourcews = sourcewb.sheet_by_name(_SheetName)
		textws = sourcewb.sheet_by_name(_InputSheetName)
	except Exception as e:
		print("Exception:",e)
	else:
		generateWarnings(sourcews, textws)
	
	