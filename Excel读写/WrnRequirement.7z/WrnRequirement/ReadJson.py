#!/usr/bin/python3

import json
import os
import xlrd
from fuzzywuzzy import fuzz

def initGlobalVar():
	global _SourceFile
	global _SheetName
	global _sourceDir

	_SourceFile	='.\\SAIC_IP31_WarningConfiguration.xlsm'
	_SheetName	='WarningConfig'
	_sourceDir = '.\\Warnings'
	
def getTableIndex(table):
	global indexInformation
	
	keyName = table.row_values(0)
	indexInformation = keyName.index("Information")
	
def readJson(fn):
	with open(fn, 'r') as f:
		data = json.load(f)
		return eval(str(data))

def getWarnings(sourceDir):
	warnings = []
	for wrnFile in os.listdir(sourceDir):
		data = readJson(sourceDir + "\\" + wrnFile)
		warnings.append([data, wrnFile])
	return warnings
	
def removeFile(fn):
	try:
		os.remove(_sourceDir + "\\" + fn)
		print(fn + " is deleted!")
	except:
		print(fn + " is not found!")

def getNewWarnings(sourceSheet):
	getTableIndex(sourceSheet)

	f = open("log.txt", "w")
	warnings = getWarnings(_sourceDir)
	for wrn in warnings:
		matchdegree = 0
		matchvalue = ""
		matchfile = ""
		for i in range(1, sourceSheet.nrows):
			if wrn[0]['Chinese'] == sourceSheet.cell(i, indexInformation).value:
				removeFile(wrn[1])
				
			degree = fuzz.ratio(wrn[0]['Chinese'], sourceSheet.cell(i, indexInformation).value)
			if matchdegree<degree:
				matchdegree = degree
				matchvalue = sourceSheet.cell(i, indexInformation).value
				matchfile = wrn[1]

		if matchdegree>0:
			print(wrn[0]['Chinese'] + " ?= " + matchvalue + ", " + matchfile + "\n")
			f.write(wrn[0]['Chinese'] + " ?= " + matchvalue + ", " + matchfile + "\n")
			#removeFile(matchfile)

	f.close()
			
					
if __name__ == "__main__":
	initGlobalVar()
	try:
		sourcewb = xlrd.open_workbook(_SourceFile)
		sourcews = sourcewb.sheet_by_name(_SheetName)
	except Exception as e:
		print("Exception:",e)
	else:
		getNewWarnings(sourcews)






















