import os
import xlrd
import json
import shutil

#os.chdir('C:\\Users\\uidp8103\\Desktop\\TextCompare\\python\\done\\TestCase')

def initGlobalVar():
	global _SourceFile
	global _SheetName
	global _distDir

	_SourceFile	='.\\SAIC_IP31_Platform_IC_UI.xlsx'
	_SheetName	='Message_EP22'
	_distDir = '.\\InputWarnings'

def getTableIndex(table):
	global indexChinese
	global indexEnglish
	global indexDisplayModeOff
	global indexDisplayModeOn
	global indexLightcolor
	global indexInformation
	
	keyName = table.row_values(1)
	indexChinese = keyName.index("中文")
	indexEnglish = keyName.index("English")
	indexDisplayModeOff = keyName.index("OFF")
	indexDisplayModeOn = keyName.index("ON")
	indexLightcolor = keyName.index("灯颜色")
	indexInformation = keyName.index("流转")

def writeJson(fn, js):
	with open(fn, 'w') as f:
		json.dump(js, f, indent=4, sort_keys=True, ensure_ascii=False)

def generateWarnings(sourceSheet):
	getTableIndex(sourceSheet)
	
	print(sourceSheet.nrows)
	for i in range(2,sourceSheet.nrows):
		Name = sourceSheet.cell(i,indexChinese).value
		Name = Name.replace("\n", "")
		
		Chinese = sourceSheet.cell(i,indexChinese).value
		listTemp = Chinese.split("\n")
		ChineseLine1 = listTemp[0]
		ChineseLine2 = ""
		if len(listTemp)>1:
			ChineseLine2 = listTemp[1]
		
		English = sourceSheet.cell(i,indexEnglish).value
		listTemp = English.split("\n")
		EnglishLine1 = listTemp[0]
		EnglishLine2 = ""
		if len(listTemp)>1:
			EnglishLine2 = listTemp[1]
		
		DisplayModeOff = sourceSheet.cell(i,indexDisplayModeOff).value
		DisplayModeOn = sourceSheet.cell(i,indexDisplayModeOn).value
		DisplayMode = ""
		if DisplayModeOff!="":
			if DisplayModeOn!="":
				DisplayMode = "IgnOFF_IgnON"
			else:
				DisplayMode = "IgnOFF"
		else:
			if DisplayModeOn!="":
				DisplayMode = "IgnON"
			else:
				DisplayMode = ""

		Information = sourceSheet.cell(i,indexInformation).value
		InforCenter = ""
		if Information!="":
			InforCenter = "Yes"

		Lightcolor = sourceSheet.cell(i,indexLightcolor).value
		if Lightcolor=="Y":
			Lightcolor = "Yellow"
		if Lightcolor=="R":
			Lightcolor = "Red"

		ChineseLine1 = ChineseLine1.replace(" ", "")
		ChineseLine2 = ChineseLine2.replace(" ", "")
		EnglishLine1 = EnglishLine1.replace(" ", "")
		EnglishLine2 = EnglishLine2.replace(" ", "")
		_wrn = {"Name":	Name,
				"ChineseLine1":	ChineseLine1,
				"ChineseLine2":	ChineseLine2,
				"EnglishLine1":	EnglishLine1,
				"EnglishLine2":	EnglishLine2,
				"DisplayMode":	DisplayMode,
				"InforCenter":	InforCenter,
				"Lightcolor":	Lightcolor
				}
		
		wrnFileName = Name.replace("\n", "").replace(" ", "").replace("/", "")
		i = 2
		if os.path.exists(_distDir + "\\"+ wrnFileName +".json")==True:
			wrnFileName = wrnFileName + str(i)
			while os.path.exists(_distDir + "\\"+ wrnFileName +".json")==True:
				i+= 1
				wrnFileName = wrnFileName[:-1] + str(i)
				
		writeJson(_distDir + "\\"+ wrnFileName +".json", _wrn)
		#print(Name)


if __name__ == "__main__":

	initGlobalVar()

	if os.path.exists(_distDir):
		shutil.rmtree(_distDir)
	
	os.mkdir(_distDir)

	try:
		sourcewb = xlrd.open_workbook(_SourceFile)
		sourcews = sourcewb.sheet_by_name(_SheetName)
	except Exception as e:
		print("Exception:",e)
	else:
		generateWarnings(sourcews)

	
	