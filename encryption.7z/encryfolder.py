#!/usr/bin/python3
# -*- coding: UTF-8 -*-

import os
import sys
import encryptselfdef

def encryptfile(inputfile, encryptedfile):

	file_origin = open(inputfile, 'r', encoding='utf-8')
	str_origin = file_origin.read()
	file_origin.close()
	
	str_encrypt = encryptselfdef.encrypt(str_origin)
	
	file_encrypted = open(encryptedfile, 'w', encoding='utf-8')
	file_encrypted.write(str_encrypt)
	file_encrypted.close()

def encryptfiles(folder):
	
	for root, dirs, files in os.walk(folder, topdown=False):
		for name in files:
			filename = os.path.join(root, name)
			encryptfile(filename, filename + '_encrypted')
			os.remove(filename)

if __name__=='__main__':
	
	dir_base = 'base'
	
	try:
		if os.path.exists( sys.argv[1] ):
			dir_base = sys.argv[1]
	except Exception as e:
		print('''Use the default folders! ''')

	print('All the files of ' + dir_base + ' are encrypted!')
	encryptfiles(dir_base)
	