#!/usr/bin/python3
# -*- coding: UTF-8 -*-

import os
import sys
import encryptselfdef


def decryptfile(inputfile, decryptedfile):

	file_origin = open(inputfile, 'r', encoding='utf-8')
	str_origin = file_origin.read()
	file_origin.close()
	
	str_decrypt = encryptselfdef.decrypt(str_origin)
	
	file_encrypted = open(decryptedfile, 'w', encoding='utf-8')
	file_encrypted.write(str_decrypt)
	file_encrypted.close()

def decryptfiles(folder):
	
	for root, dirs, files in os.walk(folder, topdown=False):
		for name in files:
			filename = os.path.join(root, name)
			if filename.rfind('_encrypted')!=-1:
				decryptfile(filename, filename[:-10])
				os.remove(filename)

if __name__=='__main__':
	
	dir_base = 'base'
	
	try:
		if os.path.exists( sys.argv[1] ):
			dir_base = sys.argv[1]
	except Exception as e:
		print('''Use the default folders! ''')

	print('All the files of ' + dir_base + ' are decrypted!')
	decryptfiles(dir_base)
	
