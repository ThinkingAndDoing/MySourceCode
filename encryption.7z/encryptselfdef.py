#!/usr/bin/python3
# -*- coding: UTF-8 -*-

global int_Key
global str_Encode

int_Key = 23
str_Encode = "gbk"

def encrypt(str_text):
	b = bytearray(str(str_text).encode(str_Encode))
	n = len(b) # 求出 b 的字节数
	c = bytearray(n*2)
	j = 0
	for i in range(0, n):
		b1 = b[i]
		b2 = b1 ^ int_Key # b1 = b2^ int_Key
		c1 = b2 % 16
		c2 = b2 // 16 # b2 = c2*16 + c1
		c1 = c1 + 65
		c2 = c2 + 65 # c1,c2都是0~15之间的数,加上65就变成了A-P 的字符的编码
		c[j] = c1
		c[j+1] = c2
		j = j+2
	return c.decode(str_Encode)

def decrypt(str_text):
	c = bytearray(str(str_text).encode(str_Encode))
	n = len(c) # 计算 b 的字节数
	if n % 2 != 0 :
		return ""
	n = n // 2
	b = bytearray(n)
	j = 0
	for i in range(0, n):
		c1 = c[j]
		c2 = c[j+1]
		j = j+2
		c1 = c1 - 65
		c2 = c2 - 65
		b2 = c2*16 + c1
		b1 = b2^ int_Key
		b[i]= b1
	try:
		return b.decode(str_Encode)
	except:
		return "failed"